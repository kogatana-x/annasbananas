/* Name: Anna Andler
 * Class: SE 450
 * Date: 10/3/2023
 * File Name: Printable.java
 * Description: defines requirement for printing patient information 
 */
package edu.depaul;

public interface Printable{
    public String toString();
}