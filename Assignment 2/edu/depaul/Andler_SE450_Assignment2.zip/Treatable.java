/* Name: Anna Andler
 * Class: SE 450
 * Date: 10/3/2023
 * File Name: Treatable.java
 * Description: Interface for defining treatable patients
 */
package edu.depaul;

public interface Treatable {
    public String treat();
}
